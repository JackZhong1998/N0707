let activeRequest = null;

function emit(status, detail = {}) {
  if (!activeRequest) return;
  chrome.runtime.sendMessage({
    type: 'NOWBUILD_CHANNEL_EVENT',
    requestId: activeRequest.requestId,
    status,
    ...detail,
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitFor(selector, timeout = 20000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const element = document.querySelector(selector);
    if (element) return element;
    await sleep(250);
  }
  throw new Error(`Timed out waiting for ${selector}`);
}

function insertText(element, text) {
  element.focus();
  document.execCommand('selectAll', false);
  document.execCommand('insertText', false, text);
  element.dispatchEvent(
    new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: text,
    })
  );
}

function findPublishedUrl(expectedText) {
  if (/\/status\/\d+/.test(window.location.pathname)) return window.location.href;
  const prefix = expectedText.trim().slice(0, 50);
  const posts = document.querySelectorAll('[data-testid="tweet"]');
  for (const post of posts) {
    if (prefix && !post.textContent?.includes(prefix)) continue;
    const link = post.querySelector('a[href*="/status/"]');
    if (link?.href) return link.href;
  }
  const toastLink = document.querySelector(
    '[data-testid="toast"] a[href*="/status/"], [role="alert"] a[href*="/status/"]'
  );
  return toastLink?.href || null;
}

function watchForPublish(expectedText) {
  const publishButtons =
    '[data-testid="tweetButton"], [data-testid="tweetButtonInline"]';
  let publishClicked = false;
  document.addEventListener(
    'click',
    (event) => {
      if (event.target?.closest?.(publishButtons)) {
        publishClicked = true;
        emit('publishing', { message: '正在等待 X 确认发布结果' });
      }
    },
    true
  );

  const timer = window.setInterval(() => {
    if (!publishClicked) return;
    const url = findPublishedUrl(expectedText);
    if (!url) return;
    window.clearInterval(timer);
    emit('published', {
      message: 'X 帖子已发布',
      postUrl: url,
    });
  }, 750);
}

async function start(request) {
  activeRequest = request;
  try {
    const editor = await waitFor('[data-testid="tweetTextarea_0"]');
    const text = [request.content.title, request.content.body]
      .filter(Boolean)
      .join('\n\n');
    insertText(editor, text);
    watchForPublish(text);
    emit('awaiting_user', {
      message: '内容已填入 X，请检查后点击“发布”',
    });
  } catch (error) {
    emit('failed', {
      error: error?.message || '无法填写 X 发布页面',
    });
  }
}

chrome.runtime.onMessage.addListener((request) => {
  if (request?.type === 'NOWBUILD_CHANNEL_START') void start(request);
});

chrome.runtime.sendMessage({
  type: 'NOWBUILD_CHANNEL_READY',
  channel: 'twitter_x',
});
